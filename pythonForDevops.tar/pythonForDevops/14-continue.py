for var in "Geeksforgeeks":
	if var == "e":
		continue
	print(var)
