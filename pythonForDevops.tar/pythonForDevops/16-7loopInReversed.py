# python code to demonstrate working of reversed()

# initializing list
lis = [1, 3, 5, 6, 2, 1, 3]


# using reversed() to print the list in reversed order
print("The list in reversed order is : ")
for i in reversed(lis):
	print(i, end=" ")
