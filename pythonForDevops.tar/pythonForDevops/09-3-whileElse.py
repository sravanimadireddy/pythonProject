# Python program to demonstrate 
# while-else loop 

i = 0
while i < 4: 
	i += 1
	print(i) 
else: # Executed because no break in for 
	print("No Break\n") 

i = 0
while i < 4: 
	i += 1
	print(i) 
	break
else: # Not executed as there is a break 
	print("No Break") 
