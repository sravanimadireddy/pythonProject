'''
Python while loop with Python list
In this example, we have run a while loop over a list that will run until there is an element present in the list.
'''


# checks if list still 
# contains any element 
a = [1, 2, 3, 4] 

while a: 
	print(a.pop())
