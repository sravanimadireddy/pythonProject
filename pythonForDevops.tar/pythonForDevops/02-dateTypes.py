#int
a = 1

#boolean
b = True
c = False

#float
d = 2.22

#complex
e = 2+3j

print(a)
print(b)
print(c)
print(d)
print(e)

#type conversion
print(float(a))
print(b)
print(c)
print(int(d))
print(str(e))
