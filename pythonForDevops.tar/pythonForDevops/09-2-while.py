age = 28

# the test condition is always True 
while age > 19: 
	print('Infinite Loop')