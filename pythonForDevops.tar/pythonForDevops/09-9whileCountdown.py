countdown = 10
while countdown > 0: 
	print(countdown) 
	countdown -= 1
print("Blast off!") 
