listOfNumbers = [1,2,3,4,5,6,7,8]
a = int(input("Enter the numbers between 0 and 7 or -1 to -8-->"))
b = int(input("Enter the numbers between 0 and 7 or -1 to -8-->"))
one = listOfNumbers[a]
two = listOfNumbers[b]
print("Addition of two index numbers",a,"and",b," of listOfNumbers =", listOfNumbers, "is ::", one+two)