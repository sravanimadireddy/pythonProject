num = 0
for i in range(10): 
	num += 1
	if num == 8:
		break
	print("The num has value:", num) 
print("Out of loop")
