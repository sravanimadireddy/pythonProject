#Hello world program
print("\nHello World")
'''
nForDevops/helloWorld.py
Hello 
World
'''
