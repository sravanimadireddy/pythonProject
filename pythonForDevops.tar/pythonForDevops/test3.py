'''list = []
n = int(input("enter number of list elements:"))
for i in range(0, n):
    ele = int(input("enter integer value :"))
    list.append(ele)
print(list)
a = list[0]
b = list[1]
c = a+b
print(c)
'''
'''
list = [1, 2, 3, 4]
print(list[0] + list[1])
'''

'''
string = "anil"
strring1 = "sravani"

print (strring1 + " " + string)
'''


'''
numbers = [9,2,3,]
numbers.sort()
print(numbers)

numbers.sort(reverse = True)
print(numbers)
print(numbers[0] + numbers[1])
'''
