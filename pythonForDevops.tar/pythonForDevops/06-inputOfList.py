#Get a list as input from user in Python List of lists as input 
lst = []
n = int(input("Enter number of elements : "))

for i in range(0, n):
	ele = [input(), int(input())]
	lst.append(ele)

print(lst)
