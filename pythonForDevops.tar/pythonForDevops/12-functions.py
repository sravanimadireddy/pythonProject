#Calling a Function
#To call a function, use the function name followed by parenthesis:
def my_function():
  print("Hello from a function")

my_function()