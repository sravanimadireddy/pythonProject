cars = ['Ford', 'BMW', 'Volvo']

cars.sort()

print(cars)