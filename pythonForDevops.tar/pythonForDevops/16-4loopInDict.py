# python code to demonstrate working of items()

king = {'Ashoka': 'The Great', 'Chandragupta': 'The Maurya','Modi': 'The Changer'}

# using items to print the dictionary key-value pair
for key, value in king.items():
	print(key, value)
